# R2 to Supabase Integration Documentation

## Overview

This documentation provides a comprehensive guide to the integration between Cloudflare R2 storage and Supabase database. This integration ensures that all images stored in R2 are accessible through Supabase, making them instantly available for compositions.

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Implementation Components](#implementation-components)
3. [Required API Keys and Credentials](#required-api-keys-and-credentials)
4. [Setup Instructions](#setup-instructions)
5. [Code Samples](#code-samples)
6. [Best Practices](#best-practices)
7. [Troubleshooting](#troubleshooting)

## Architecture Overview

The integration consists of two main components:

1. **Initial Data Import**: A process to import existing R2 images into Supabase
2. **Real-time Integration**: A mechanism to ensure new uploads to R2 are simultaneously added to Supabase

This architecture ensures that all images, both existing and newly uploaded, are instantly available for compositions through Supabase queries.

## Implementation Components

### 1. CSV Export and Import

For existing files in R2, we created a script (`r2_to_csv.py`) that:
- Lists all folders in the R2 bucket
- Extracts all image files in each folder
- Creates a CSV file with image URLs
- Imports this CSV into Supabase

### 2. Folder Information Extraction

To enhance querying capabilities, we created a script (`extract_folders.py`) that:
- Extracts folder names from image URLs
- Updates the Supabase database with this information

### 3. Real-time Upload Integration

For new uploads, we created a server (`upload_server.py`) that:
- Receives file uploads
- Uploads files to R2
- Simultaneously updates Supabase with the new image URL and folder information

## Required API Keys and Credentials

The following API keys and credentials are required:

### Cloudflare R2

- **Account ID**: `a257d20748dbf6badd898ffcf58e8f3d`
- **Access Key ID**: `a413c342ed225561bac74222f98d9a34`
- **Secret Access Key**: `1b876c301bf2bd3c123cc659964ce14e1f50fc197f2cfcc51f5cb2a887892063`
- **R2 Endpoint**: `https://a257d20748dbf6badd898ffcf58e8f3d.r2.cloudflarestorage.com`
- **Public Development Key**: `https://pub-8b56cc2df3754875846b860a86f9bd7c.r2.dev`

### Supabase

- **URL**: `https://ppbbtcbqjpsoqvtjinoe.supabase.co`
- **API Key**: Your Supabase API key (not provided in the documentation for security reasons)

## Setup Instructions

Detailed setup instructions are provided in the [SETUP.md](SETUP.md) file.

## Code Samples

Code samples for each component are provided in the following files:
- [r2_to_csv.py](r2_to_csv.py): Script for exporting R2 images to CSV
- [extract_folders.py](extract_folders.py): Script for extracting folder information
- [upload_server.py](upload_server.py): Server for real-time integration

## Best Practices

Best practices for maintaining and extending this integration are provided in the [BEST_PRACTICES.md](BEST_PRACTICES.md) file.

## Troubleshooting

Common issues and their solutions are provided in the [TROUBLESHOOTING.md](TROUBLESHOOTING.md) file.

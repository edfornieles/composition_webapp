"""
R2 to CSV Export Script

This script exports image files from Cloudflare R2 storage to a CSV file
that can be imported into Supabase.

Usage:
    python r2_to_csv.py

Environment Variables:
    R2_BUCKET_NAME: Name of your R2 bucket (default: 'cloudflare_r2_new')
    R2_BUCKET_PATH: Path within the bucket (default: 'composition-sources')
    R2_PUBLIC_URL: Public URL for accessing files in your R2 bucket
    CSV_OUTPUT_PATH: Path to save the CSV file (default: 'r2_images.csv')
"""

import subprocess
import json
import csv
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configuration
bucket_name = os.getenv('R2_BUCKET_NAME', 'cloudflare_r2_new')
bucket_path = os.getenv('R2_BUCKET_PATH', 'composition-sources')
public_url_base = os.getenv('R2_PUBLIC_URL', 'https://pub-8b56cc2df3754875846b860a86f9bd7c.r2.dev')
csv_output_path = os.getenv('CSV_OUTPUT_PATH', 'r2_images.csv')

def run_rclone_command(command):
    """
    Run an rclone command and return the output.
    
    Args:
        command: List of command parts
        
    Returns:
        Command output as string
    """
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error running command: {' '.join(command)}")
        print(f"Error: {result.stderr}")
        return None
    return result.stdout

def main():
    """
    Main function to export R2 images to CSV.
    """
    print(f"Exporting images from {bucket_name}:{bucket_path} to {csv_output_path}")
    
    # Get all folders in the bucket
    print("Fetching folder list from R2...")
    command = ["rclone", "lsjson", f"{bucket_name}:{bucket_path}", "--no-mimetype", "--dirs-only"]
    folders_json = run_rclone_command(command)
    if not folders_json:
        print("Failed to fetch folders. Check your R2 configuration.")
        return
        
    folders = json.loads(folders_json)
    print(f"Found {len(folders)} folders to process...")
    
    # Open CSV file for writing
    with open(csv_output_path, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)
        # Write header
        csv_writer.writerow(['image_url', 'created_at'])
        
        total_files_processed = 0
        
        # Process each folder
        for folder_index, folder in enumerate(folders):
            folder_name = folder['Path']
            print(f"\nProcessing folder {folder_index+1}/{len(folders)}: {folder_name}")
            
            # List files in this folder
            command = ["rclone", "lsjson", f"{bucket_name}:{bucket_path}/{folder_name}", 
                      "--no-mimetype", "--exclude=._*", "--exclude=.DS_Store"]
            files_json = run_rclone_command(command)
            if not files_json:
                print(f"Failed to fetch files for folder {folder_name}. Skipping.")
                continue
                
            files = json.loads(files_json)
            
            # Filter out directories
            files = [file for file in files if not file["IsDir"]]
            
            print(f"Found {len(files)} files in {folder_name}...")
            files_processed = 0
            
            # Process files
            for file in files:
                # Create the full public URL
                image_url = f"{public_url_base}/{bucket_path}/{folder_name}/{file['Path']}"
                
                # Write to CSV
                csv_writer.writerow([image_url, file.get('ModTime', '')])
                
                files_processed += 1
                total_files_processed += 1
                
                # Print progress every 100 files
                if files_processed % 100 == 0:
                    print(f"Processed {files_processed}/{len(files)} files in this folder...")
            
            print(f"Completed folder {folder_name}: Processed {files_processed} files")
    
    print(f"\nExport completed successfully!")
    print(f"Total folders processed: {len(folders)}")
    print(f"Total files processed: {total_files_processed}")
    print(f"CSV file saved to: {csv_output_path}")
    print("\nYou can now import this CSV file into your Supabase database.")

if __name__ == "__main__":
    main()

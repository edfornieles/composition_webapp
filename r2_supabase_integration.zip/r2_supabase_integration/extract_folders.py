"""
Extract Folder Information Script

This script extracts folder names from image URLs in the Supabase database
and updates the records with this information.

Usage:
    python extract_folders.py

Environment Variables:
    SUPABASE_URL: URL of your Supabase project
    SUPABASE_KEY: API key for your Supabase project
"""

from supabase import create_client
import re
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Supabase client
supabase_url = os.getenv('SUPABASE_URL', 'https://ppbbtcbqjpsoqvtjinoe.supabase.co')
supabase_key = os.getenv('SUPABASE_KEY', 'your-supabase-api-key')
supabase = create_client(supabase_url, supabase_key)

def main():
    """
    Main function to extract folder information from image URLs and update the database.
    """
    # Get all image URLs from database
    print("Fetching all image URLs from database...")
    response = supabase.table('image_metadata').select('id,image_url').execute()
    
    if not response.data:
        print("No records found in the database.")
        return
        
    print(f"Found {len(response.data)} records to process.")
    
    # Process each URL to extract folder
    updated_count = 0
    for item in response.data:
        url = item['image_url']
        # Extract folder using regex
        match = re.search(r'composition-sources/([^/]+)/', url)
        if match:
            folder_name = match.group(1)
            # Update the record with folder name
            supabase.table('image_metadata').update({"folder_name": folder_name}).eq('id', item['id']).execute()
            print(f"Updated ID {item['id']} with folder: {folder_name}")
            updated_count += 1
        else:
            print(f"Could not extract folder from URL: {url}")
    
    print(f"Folder extraction completed! Updated {updated_count} out of {len(response.data)} records.")

if __name__ == "__main__":
    main()

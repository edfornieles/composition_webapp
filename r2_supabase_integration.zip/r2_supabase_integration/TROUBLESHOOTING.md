# Troubleshooting Guide for R2 to Supabase Integration

This document provides solutions for common issues you might encounter with the R2 to Supabase integration.

## Connection Issues

### R2 Connection Problems

**Issue**: Unable to connect to R2 storage.

**Solutions**:
1. Verify your R2 credentials (Access Key and Secret Key)
2. Check that your R2 endpoint URL is correct
3. Ensure your network allows connections to the R2 endpoint
4. Verify that your R2 bucket exists and is accessible

**Example Error**:
```
botocore.exceptions.ClientError: An error occurred (AccessDenied) when calling the ListBuckets operation: Access Denied
```

**Fix**:
```python
# Check your credentials
print(os.getenv('R2_ACCESS_KEY'))  # Should match your Cloudflare R2 Access Key
print(os.getenv('R2_SECRET_KEY'))  # Should match your Cloudflare R2 Secret Key

# Verify endpoint
print(os.getenv('R2_ENDPOINT'))  # Should be https://[account-id].r2.cloudflarestorage.com
```

### Supabase Connection Problems

**Issue**: Unable to connect to Supabase.

**Solutions**:
1. Verify your Supabase URL and API key
2. Check that your Supabase project is active
3. Ensure your network allows connections to Supabase
4. Verify that the `image_metadata` table exists

**Example Error**:
```
PostgrestError: Request failed with status code 401 Unauthorized
```

**Fix**:
```python
# Check your credentials
print(os.getenv('SUPABASE_URL'))  # Should match your Supabase project URL
print(os.getenv('SUPABASE_KEY'))  # Should match your Supabase API key

# Test connection
result = supabase.table('image_metadata').select('count(*)', count='exact').execute()
print(result)
```

## Upload Issues

### File Upload Failures

**Issue**: Files fail to upload to R2.

**Solutions**:
1. Check file permissions
2. Verify that the file exists and is readable
3. Ensure the file size is within limits
4. Check for network interruptions

**Example Error**:
```
botocore.exceptions.ClientError: An error occurred (NoSuchBucket) when calling the PutObject operation: The specified bucket does not exist
```

**Fix**:
```python
# Verify bucket exists
try:
    s3.head_bucket(Bucket='composition-sources')
    print("Bucket exists and is accessible")
except Exception as e:
    print(f"Bucket issue: {str(e)}")
```

### Database Update Failures

**Issue**: Files upload to R2 but fail to update in Supabase.

**Solutions**:
1. Check Supabase permissions
2. Verify table schema matches expected columns
3. Ensure the database has sufficient space
4. Check for constraint violations

**Example Error**:
```
PostgrestError: Request failed with status code 400 Bad Request
```

**Fix**:
```python
# Check table structure
result = supabase.rpc('get_table_definition', {'table_name': 'image_metadata'}).execute()
print(result.data)

# Verify insert works with minimal data
try:
    result = supabase.table('image_metadata').insert({'image_url': 'test_url'}).execute()
    print("Insert successful")
except Exception as e:
    print(f"Insert failed: {str(e)}")
```

## Data Synchronization Issues

### Missing Files in Database

**Issue**: Files exist in R2 but are missing from Supabase.

**Solutions**:
1. Run the folder extraction script again
2. Check for errors in previous sync operations
3. Verify that the CSV import completed successfully
4. Check for duplicate prevention logic that might be skipping files

**Fix**:
```bash
# Re-run the folder extraction script
python extract_folders.py

# Or run a full re-sync from R2 to CSV to Supabase
python r2_to_csv.py
# Then import the CSV into Supabase
```

### Incorrect Folder Information

**Issue**: Folder names are not correctly extracted or stored.

**Solutions**:
1. Check the regex pattern in the folder extraction script
2. Verify that URLs follow the expected format
3. Ensure the folder_name column exists in the database
4. Check for special characters in folder names that might affect extraction

**Example Issue**:
URLs don't follow the expected pattern: `composition-sources/[folder_name]/[filename]`

**Fix**:
```python
# Update the regex pattern in extract_folders.py
# Original:
match = re.search(r'composition-sources/([^/]+)/', url)

# More flexible pattern:
match = re.search(r'([^/]+)/[^/]+$', url)  # Extracts the last folder before filename
```

## Performance Issues

### Slow CSV Export

**Issue**: The CSV export process is very slow.

**Solutions**:
1. Implement pagination when listing files
2. Process folders in parallel using multiple threads
3. Optimize rclone commands with appropriate flags
4. Consider incremental exports instead of full exports

**Fix**:
```python
# Add pagination to rclone commands
command = ["rclone", "lsjson", f"{bucket_name}:{bucket_path}/{folder_name}", 
          "--no-mimetype", "--exclude=._*", "--exclude=.DS_Store",
          "--max-depth", "1", "--files-only"]
```

### Slow Database Updates

**Issue**: Database updates are slow when processing many files.

**Solutions**:
1. Use batch inserts instead of individual inserts
2. Implement pagination when selecting records
3. Add appropriate indexes to the database
4. Consider using transactions for multiple operations

**Fix**:
```python
# Batch insert example
batch_size = 100
records = []

for file in files:
    image_url = f"{public_url_base}/{bucket_path}/{folder_name}/{file['Path']}"
    records.append({
        'image_url': image_url,
        'folder_name': folder_name,
        'created_at': file.get('ModTime', '')
    })
    
    # When batch size is reached, insert and reset
    if len(records) >= batch_size:
        supabase.table('image_metadata').insert(records).execute()
        records = []

# Insert any remaining records
if records:
    supabase.table('image_metadata').insert(records).execute()
```

## Environment Issues

### Missing Environment Variables

**Issue**: Environment variables are not being loaded correctly.

**Solutions**:
1. Check that the .env file exists and is in the correct location
2. Verify that the .env file has the correct format
3. Ensure dotenv is properly imported and loaded
4. Check for typos in environment variable names

**Fix**:
```python
# Explicitly specify .env file location
from dotenv import load_dotenv
load_dotenv('/path/to/.env')

# Print all environment variables to debug
import os
print("R2_ENDPOINT:", os.getenv('R2_ENDPOINT'))
print("R2_ACCESS_KEY:", os.getenv('R2_ACCESS_KEY', 'Not set'))
print("SUPABASE_URL:", os.getenv('SUPABASE_URL'))
print("SUPABASE_KEY:", os.getenv('SUPABASE_KEY', 'Not set'))
```

### Package Installation Issues

**Issue**: Required Python packages are not installed or have version conflicts.

**Solutions**:
1. Verify all required packages are installed
2. Check for version conflicts
3. Consider using a virtual environment
4. Update packages to the latest compatible versions

**Fix**:
```bash
# Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install required packages
pip install flask boto3 supabase python-dotenv

# Check installed versions
pip freeze | grep -E 'flask|boto3|supabase|python-dotenv'
```

## Production Deployment Issues

### Server Not Starting

**Issue**: The upload server fails to start in production.

**Solutions**:
1. Check for port conflicts
2. Verify that the server has the necessary permissions
3. Ensure all dependencies are installed
4. Check for syntax errors in the code

**Fix**:
```python
# Change port if 3001 is in use
if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=3001)
    except OSError:
        print("Port 3001 is in use, trying alternative port 3002")
        app.run(host='0.0.0.0', port=3002)
```

### Memory Issues

**Issue**: The server runs out of memory when handling large files.

**Solutions**:
1. Implement streaming uploads for large files
2. Set appropriate file size limits
3. Optimize memory usage in the code
4. Consider using a more efficient WSGI server

**Fix**:
```python
# Set file size limit in Flask
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Stream large files to R2
@app.route('/upload_large', methods=['POST'])
def upload_large_file():
    file = request.files['file']
    folder_name = request.form.get('folderName', 'default-folder')
    unique_filename = f"{uuid.uuid4()}{os.path.splitext(file.filename)[1].lower()}"
    r2_key = f"composition-sources/{folder_name}/{unique_filename}"
    
    # Stream upload
    s3.upload_fileobj(
        file,
        'composition-sources',
        r2_key,
        ExtraArgs={'ContentType': file.content_type}
    )
    
    # Rest of the function...
```

## Need Additional Help?

If you encounter issues not covered in this guide:

1. Check the AWS S3 and Boto3 documentation for R2-related issues
2. Refer to the Supabase documentation for database-related issues
3. Review the Flask documentation for server-related issues
4. Consider reaching out to Cloudflare support for R2-specific problems
5. Check the Supabase community forums for database-specific questions

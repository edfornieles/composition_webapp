# Setup Instructions for R2 to Supabase Integration

This document provides detailed setup instructions for the R2 to Supabase integration.

## Prerequisites

Before setting up the integration, ensure you have:

1. A Cloudflare account with R2 storage enabled
2. A Supabase account with a project created
3. Python 3.6+ installed on your system
4. Required Python packages (see below)

## Required Python Packages

Install the following Python packages:

```bash
pip install flask boto3 supabase python-dotenv
```

## Environment Configuration

1. Create a `.env` file in your project directory with the following variables:

```
SUPABASE_URL=https://ppbbtcbqjpsoqvtjinoe.supabase.co
SUPABASE_KEY=your-supabase-api-key
R2_ENDPOINT=https://a257d20748dbf6badd898ffcf58e8f3d.r2.cloudflarestorage.com
R2_ACCESS_KEY=a413c342ed225561bac74222f98d9a34
R2_SECRET_KEY=1b876c301bf2bd3c123cc659964ce14e1f50fc197f2cfcc51f5cb2a887892063
R2_PUBLIC_URL=https://pub-8b56cc2df3754875846b860a86f9bd7c.r2.dev
```

Replace `your-supabase-api-key` with your actual Supabase API key.

## Supabase Database Setup

1. Create a table in Supabase called `image_metadata` with the following columns:

| Column Name    | Type      | Description                                      |
|----------------|-----------|--------------------------------------------------|
| id             | int8      | Primary key, auto-incrementing                   |
| image_url      | text      | Full URL to the image in R2                      |
| folder_name    | text      | Name of the folder containing the image          |
| composition_id | int8      | (Optional) ID of associated composition          |
| created_at     | timestamp | Timestamp when the record was created            |

You can create this table using the following SQL:

```sql
CREATE TABLE image_metadata (
  id BIGSERIAL PRIMARY KEY,
  image_url TEXT NOT NULL,
  folder_name TEXT,
  composition_id BIGINT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an index on image_url for faster lookups
CREATE INDEX idx_image_metadata_url ON image_metadata(image_url);

-- Create an index on folder_name for faster filtering
CREATE INDEX idx_image_metadata_folder ON image_metadata(folder_name);
```

## Initial Data Import

To import existing R2 images into Supabase:

1. Run the CSV export script:
   ```bash
   python r2_to_csv.py
   ```

2. Import the generated CSV file into Supabase:
   - Go to your Supabase dashboard
   - Select your project
   - Go to "Table Editor" > "image_metadata"
   - Click "Import" and select the CSV file

3. Run the folder extraction script to update folder information:
   ```bash
   python extract_folders.py
   ```

## Real-time Integration Setup

To set up the real-time integration:

1. Start the upload server:
   ```bash
   python upload_server.py
   ```

2. The server will run on port 3001 by default. You can change this in the script if needed.

3. Test the upload functionality:
   ```bash
   curl -F "file=@/path/to/test/image.jpg" -F "folderName=test-folder" http://localhost:3001/upload
   ```

## Production Deployment

For production deployment:

1. Integrate the upload logic from `upload_server.py` into your existing backend code
2. Ensure environment variables are properly set in your production environment
3. Implement proper error handling and logging
4. Consider using a production-ready WSGI server like Gunicorn instead of Flask's development server

## Verification

To verify the integration is working correctly:

1. Check that files appear in your R2 bucket:
   ```bash
   rclone ls cloudflare_r2:composition-sources
   ```

2. Check that records are added to your Supabase database with the correct image URL and folder name

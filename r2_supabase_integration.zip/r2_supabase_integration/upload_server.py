"""
R2 to Supabase Upload Server

This script provides a Flask server that handles file uploads to Cloudflare R2
and simultaneously updates a Supabase database with the new image URL and folder information.

Usage:
    python upload_server.py

Environment Variables:
    SUPABASE_URL: URL of your Supabase project
    SUPABASE_KEY: API key for your Supabase project
    R2_ENDPOINT: Endpoint URL for your Cloudflare R2 storage
    R2_ACCESS_KEY: Access key for your Cloudflare R2 storage
    R2_SECRET_KEY: Secret key for your Cloudflare R2 storage
    R2_PUBLIC_URL: Public URL for accessing files in your R2 bucket
"""

from flask import Flask, request, jsonify
import boto3
from supabase import create_client
import os
from datetime import datetime
from dotenv import load_dotenv
import uuid

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Initialize Supabase client
supabase_url = os.getenv('SUPABASE_URL', 'https://ppbbtcbqjpsoqvtjinoe.supabase.co')
supabase_key = os.getenv('SUPABASE_KEY', 'your-supabase-api-key')
supabase = create_client(supabase_url, supabase_key)

# Initialize R2 client
s3 = boto3.client('s3',
    endpoint_url=os.getenv('R2_ENDPOINT', 'https://a257d20748dbf6badd898ffcf58e8f3d.r2.cloudflarestorage.com'),
    aws_access_key_id=os.getenv('R2_ACCESS_KEY', 'a413c342ed225561bac74222f98d9a34'),
    aws_secret_access_key=os.getenv('R2_SECRET_KEY', '1b876c301bf2bd3c123cc659964ce14e1f50fc197f2cfcc51f5cb2a887892063')
)

# Get public URL base from environment or use default
public_url_base = os.getenv('R2_PUBLIC_URL', 'https://pub-8b56cc2df3754875846b860a86f9bd7c.r2.dev')

@app.route('/upload', methods=['POST'])
def upload_file():
    """
    Handle file uploads to R2 and update Supabase database.
    
    Expected form data:
        file: The file to upload
        folderName: The folder to upload the file to (default: 'default-folder')
        composition_id: (Optional) ID of the associated composition
        
    Returns:
        JSON response with upload status and file information
    """
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file part'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No selected file'}), 400
            
        # Get folder name from request or use default
        folder_name = request.form.get('folderName', 'default-folder')
        
        # Extract file information
        file_ext = os.path.splitext(file.filename)[1].lower()
        unique_filename = f"{uuid.uuid4()}{file_ext}"
        
        # 1. Upload to R2
        r2_key = f"composition-sources/{folder_name}/{unique_filename}"
        s3.upload_fileobj(
            file,
            'composition-sources',
            r2_key,
            ExtraArgs={'ContentType': file.content_type}
        )
        
        # 2. Update Supabase
        image_url = f"{public_url_base}/{r2_key}"
        
        # Store folder information in the database
        result = supabase.table('image_metadata').insert({
            'image_url': image_url,
            'composition_id': request.form.get('composition_id'),  # Optional
            'folder_name': folder_name,  # Store folder information
            'created_at': datetime.now().isoformat()
        }).execute()
        
        return jsonify({
            'success': True,
            'message': 'File uploaded and database updated',
            'imageUrl': image_url,
            'folderName': folder_name,
            'databaseId': result.data[0]['id'] if result.data else None
        })
        
    except Exception as e:
        print(f"Upload error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=3001)
